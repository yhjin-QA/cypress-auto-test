/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/*!********************************!*\
  !*** ./cypress/e2e/spec.cy.js ***!
  \********************************/
  // ▼ 1. 모든 에러 무시 설정 (강력한 방어막) ▼
  Cypress.on('uncaught:exception', (err, runnable) => {
    // 무시할 에러 메시지 목록
    const ignoredErrors = [
      'Navigation cancelled',
      'Cannot read properties',
      'resetValidation',
      'NavigationDuplicated', // [NEW] 중복 이동 에러 무시 추가
      'Redirected when going from', // ◀◀◀ 이 문구를 추가하세요!
      'navigation guard',           // ◀◀◀ 이 문구도 추가하세요!
      'Avoided redundant navigation',
      'Loading chunk',
      'Loading CSS chunk',           // ◀◀◀ [NEW] 이번에 발생한 CSS 청크 에러 무시 추가!
      'operate.task.packageManagement',
      'e is not defined',
      'Script error',
      'not valid JSON',
      'ChunkLoadError'
    ];

    // 위 목록 중 하나라도 포함되면 에러를 무시함
    if (ignoredErrors.some(e => err.message.includes(e))) {
      return false;
    }
  });

/**코드 시작  */
describe('로그캐치 사이트 테스트', () => {
  
  it('로그캐치 배포점검목록 동작 체크', () => {


    // ==========================================
    // STEP 1: 로그인
    // ==========================================
    // 1. 사이트 방문
    cy.visit('https://10.10.54.21:18443/logcatch/login');
    cy.wait(5000); // 로딩 대기

    ////////////새로고침코드//////
      cy.get('body').then(($body) => {
      // 만약 입력창이 안 보인다면? (흰 화면 상태라면?)
      if ($body.find('input[aria-label="사용자 계정"]').length === 0) {
        cy.log('🔴 화면 렌더링 실패 감지! 페이지를 새로고침합니다.');
    
      // 새로고침 실행
      cy.reload();
    
      // 다시 한번 안정화 대기
      cy.wait(2000);
      } else {
        cy.log('🟢 화면이 정상적으로 로드되었습니다.');
      }
     });
     //////////////////////////////////////

    // 2. 아이디 입력
    cy.get('input[aria-label="사용자 계정"]').should('exist').type('admin', { force: true });

    // 3. 비밀번호 입력
    cy.get('input[aria-label="패스워드"]').should('exist').type('Manager1!', { force: true }); 
    
    // 4. 로그인 실행 (버튼 클릭 대신 엔터키 사용)
    // 설명: 버튼 클릭보다 엔터키가 '중복 클릭'이나 '이동 에러'가 훨씬 적게 발생합니다.
    cy.get('input[aria-label="패스워드"]').type('{enter}', { force: true });

    

   // -----------------------------------------------------------
   // [추가된 부분] "이미 로그인" 알림창 처리 (조건부 로직)
   // -----------------------------------------------------------
   cy.wait(2000); // 팝업이 뜨는 찰나의 시간을 기다려줍니다.
   cy.get('body').then(($body) => {
    
    // 2. jQuery 문법(.find)으로 해당 요소가 있는지 '길이(length)'로 체크합니다.
    // 주의: 여기서는 cy.contains를 쓰면 안 됩니다!
    if ($body.find('.v-card__title:contains("이미 접속 중인 계정입니다."):visible').length > 0) {
        
        cy.log('⚠️ 알림창 발견! 확인 버튼을 클릭합니다.');

        // 3. 요소가 있다는 게 확실해졌으니, 이제 안심하고 Cypress 명령어를 씁니다.
        cy.contains('.v-card__title', '이미 접속 중인 계정입니다.')
          .closest('.v-card')
          .contains('확인')
          .click(); // 여기서 force: true를 주면 더 안전합니다.
          
        cy.wait(1000); // 팝업 닫힘 대기
    } else {
        cy.log('✅ 알림창이 없습니다. 넘어갑니다.');
    }
});

    // 5. [중요] 로그인 성공 검증 (URL 변경 확인)
    // 로그인이 성공해서 URL에서 '/login'이 빠질 때까지 최대 10초간 기다립니다.
    // 만약 여기서 실패한다면 "아이디/비번"이 틀렸거나 서버 문제(Access Deny)입니다.
    cy.url({ timeout: 10000 }).should('not.include', '/login');
    // -----------------------------------------------------------

     
    //6. 화면 안정화 대기
     cy.wait(3000);
    
    //로그인 성공
  
  
    // ==========================================
    // 테스트 자동화시나리오
    // 이력 - 자동화 시니라오 테스트 
    // ==========================================

    cy.contains('button', '이력').should('be.visible').click({ force: true });
    cy.wait(1000); // 서브 메뉴가 펼쳐질 시간 대기


    // 이력 > 사용자 추척 서브메뉴 클릭 
    cy.log('--- 이력 > 사용자 추적 클릭 ---');
    // 설명: .v-list__tile__title 클래스 내의 '사용자 추적' 글자를 찾아 클릭
    cy.contains('.v-list__tile__title', '사용자 추적').should('be.visible').click({ force: true });
    cy.wait(3000);
    cy.log('--- 화면 검증 시작 ---');
    cy.contains('.c-headline', '검색 조건').should('exist');
  
    // 검색 조건 이름 입력란 확인
     cy.get('input[aria-label="부서/소속"]').filter(':visible').should('be.visible');
     cy.get('input[aria-label="정보 사용자"]').filter(':visible').should('be.visible');
     cy.get('input[aria-label="사용자 계정"]').filter(':visible').should('be.visible');
     cy.get('input[aria-label="사용자 IP"]').filter(':visible').should('be.visible');
     cy.get('input[aria-label="URI 주소"]').filter(':visible').should('be.visible');
     cy.get('input[aria-label="행위 유형"]').filter(':visible').should('be.visible');
  
     // 시작날짜 달력 아이콘확인
     cy.contains('기간').closest('.v-input').find('.material-icons').contains('event').should('be.visible');
     // 종료날짜 달력 아이콘확인
     cy.get('input[type="text"][readonly="readonly"]').filter(':visible').eq(1).closest('.v-input').find('.material-icons:contains("event")').should('be.visible');
     // 전체선택 확인
     cy.get('span[title="전체 선택"]').should('be.visible');
     // like버튼 확인 
     //cy.get('.v-chip__content').filter(':visible').contains('like').should('be.visible');
    
    //검색 버튼 존재 확인
    cy.get('.v-btn__content').filter(':visible').contains('검색').should('be.visible');
    // 전체 건수 버튼 존재확인 
    cy.get('.v-btn__content').filter(':visible').contains('전체 건수').should('be.visible');
    //표열 문구확인
    cy.get('th').filter(':visible').contains('접속 일시').should('be.visible');
    cy.get('th').filter(':visible').contains('업무시스템').should('be.visible');
    cy.get('th').filter(':visible').contains('부서/소속').should('be.visible');
    cy.get('th').filter(':visible').contains('정보 사용자').should('be.visible');
    cy.get('th').filter(':visible').contains('접속 IP 주소').should('be.visible');
    cy.get('th').filter(':visible').contains('접속 메뉴').should('be.visible');
    cy.get('th').filter(':visible').contains('행위 유형').should('be.visible');
    cy.get('th').filter(':visible').contains('개인정보 유형').should('be.visible');
    cy.get('th').filter(':visible').contains('개인정보 값').should('be.visible');
    cy.get('th').filter(':visible').contains('조회').should('be.visible');

  
  
    // ==========================================
    // 테스트 자동화시나리오
    // 이력 - 접속기록 이력 자동화 시니라오 테스트 
    // ==========================================



    // 이력 > 접속 기록 이력 서브메뉴 클릭  -----------------------
    cy.contains('button', '이력').click({ force: true });
    cy.log('--- 이력 > 접속기록 이력  클릭 ---');
    cy.wait(3000);
    // 설명: .v-list__tile__title 클래스 내의 '사용자 추적' 글자를 찾아 클릭
    cy.contains('.v-list__tile__title', '접속기록 이력').should('be.visible').click({ force: true });
    cy.wait(3000);
  
    //이력 > 접속기록 이력 > [통합]탭 선택
    cy.get('.tab-btn').contains('통합').should('be.visible').click({ force: true });
    cy.wait(3000);
    cy.log('--- 화면 검증 시작 ---');
    cy.get('.tab-btn').contains('통합').closest('button').should('not.have.class', 'inactive');
    // 설명: 'c-headline' 클래스를 가진 요소 중에 '이상행위' 글자가 보여야 한다.
    cy.contains('.c-headline', '검색 조건').should('exist');
    // 시작날짜 달력 아이콘확인
     cy.contains('기간').closest('.v-input').find('.material-icons').contains('event').should('be.visible');
     // 종료날짜 달력 아이콘확인
     cy.get('input[type="text"][readonly="readonly"]').filter(':visible').eq(1).closest('.v-input').find('.material-icons:contains("event")').should('be.visible');
     // 검색 조건 이름 입력란 확인
     cy.get('input[aria-label="업무시스템"]').filter(':visible').should('be.visible');
     cy.get('input[aria-label="부서/소속"]').filter(':visible').should('be.visible');
     cy.get('input[aria-label="정보 사용자"][role="combobox"]').filter(':visible').should('be.visible');
     cy.get('input[aria-label="사용자 IP"]').filter(':visible').should('be.visible');
     cy.get('input[aria-label="URI 주소"]').filter(':visible').should('be.visible');
     cy.get('input[aria-label="접속 메뉴"]').filter(':visible').should('be.visible');
     cy.get('input[aria-label="행위 유형"]').filter(':visible').should('be.visible');
     cy.get('input[aria-label="개인정보 건수"]').filter(':visible').should('be.visible');
     cy.get('input[aria-label="개인정보 건수"]').parents('.v-input').find('.v-chip__content').contains('이상').should('be.visible');
      cy.get('input[aria-label="사용자 상태"]').filter(':visible').should('be.visible');

    //검색 버튼 존재확인 
    cy.get('.v-btn__content').filter(':visible').contains('검색').should('be.visible');
    // 전체 건수 버튼 존재확인 
    cy.get('.v-btn__content').filter(':visible').contains('전체 건수').should('be.visible');
    //토글 문구 확인
    cy.get('label').filter(':visible').contains('개인정보').should('be.visible');
    //표열 문구확인
    cy.get('th').filter(':visible').contains('접속 일시').should('be.visible');
    cy.get('th').filter(':visible').contains('업무시스템').should('be.visible');
    cy.get('th').filter(':visible').contains('정보 사용자').should('be.visible');
    cy.get('th').filter(':visible').contains('부서/소속').should('be.visible');
    cy.get('th').filter(':visible').contains('접속 IP 주소').should('be.visible');
    cy.get('th').filter(':visible').contains('접속 메뉴').should('be.visible');
    cy.get('th').filter(':visible').contains('행위 유형').should('be.visible');
    cy.get('th').filter(':visible').contains('개인정보 유형').should('be.visible');
    cy.get('th').filter(':visible').contains('건수').should('be.visible');
    cy.get('th').filter(':visible').contains('상세 접속기록 정보').should('be.visible');
    cy.get('th').filter(':visible').contains('처리').should('be.visible');



  // ==========================================
  // 🌟 [완벽 수정] 동적 날짜 계산 로직선언 (전월 기준)
  // ==========================================
  const today = new Date();

  // 1월에 실행할 경우 작년 12월로 넘어가야 하므로 Date 객체 자체를 한 달 전으로 돌립니다.
  const prevMonthDate = new Date(today.getFullYear(), today.getMonth() - 1, 1);

  // 기존 변수명(currentMonthText)을 그대로 유지하여 다른 코드에서 발생하는 참조 에러를 방지합니다.
  const currentMonthNum = prevMonthDate.getMonth() + 1; // 전월 숫자 (예: 4)
  const currentMonthText = `${currentMonthNum}월`; // 예: "4월"

  // 전월의 마지막 날(말일) 구하기
  const lastDayNum = new Date(prevMonthDate.getFullYear(), currentMonthNum, 0).getDate(); 

  const firstDayRegex = new RegExp(`^\\s*1일\\s*$`);
  const lastDayRegex = new RegExp(`^\\s*${lastDayNum}일\\s*$`);
  cy.log(`📅 동적 기간 세팅 준비 완료: ${currentMonthText} 1일 ~ ${lastDayNum}일`);



    // // ==========================================
    // // 🌟 [추가] 동적 날짜 계산 로직 (현재 달 기준)
    // // ==========================================
    // const today = new Date();
    // const currentMonthNum = today.getMonth() + 1; // 이번 달 숫자 (예: 5, 6)
    // const currentMonthText = `${currentMonthNum}월`; // 예: "5월", "6월"

    // // 💡 Date 객체의 일(Day) 자리에 0을 넣으면 '이전 달의 마지막 날'을 구해주는 꼼수를 사용합니다!
    // // 즉, 다음 달의 0일 = 이번 달의 말일이 됩니다.
    // const lastDayNum = new Date(today.getFullYear(), currentMonthNum, 0).getDate(); 

    // // 동적 정규식 생성 (공백 무시하고 정확히 매칭)
    // const firstDayRegex = new RegExp(`^\\s*1일\\s*$`);
    // const lastDayRegex = new RegExp(`^\\s*${lastDayNum}일\\s*$`);
    // cy.log(`📅 동적 기간 세팅 준비 완료: ${currentMonthText} 1일 ~ ${lastDayNum}일`);


    //달력표를 펼침  
    // ==========================================
    // '기간 시작일자' 셋팅 ( 1일)
    // ==========================================
    cy.log(`📅 대상기간 시작일자를 ${currentMonthText} 1일로 셋팅합니다.`);
    //cy.contains('기간').closest('.v-input').find('.material-icons').contains('event').click({ force: true });
     cy.get('input[type="text"][readonly="readonly"]').filter(':visible').eq(0) .closest('.v-input').find('.material-icons').contains('event').click({ force: true });
    cy.wait(1000);

    // 연/월 선택 모드로 변경하여 '이번 달(동적 변수)' 선택
    cy.get('.menuable__content__active').find('.v-date-picker-header__value button').click({ force: true });
    cy.get('.v-date-picker-table--month').filter(':visible').contains(currentMonthText).click({ force: true });

    // 1일 선택
    cy.get('.v-date-picker-table').filter(':visible').contains('.v-btn__content', firstDayRegex).closest('.v-btn').click({ force: true });
    cy.get('body').type('{esc}');
    cy.wait(1000);

    // ==========================================
    // '기간 종료일자' 셋팅 (말일)
    // ==========================================
    cy.log(`📅 대상기간 종료일자를 ${currentMonthText} ${lastDayNum}일로 셋팅합니다.`);
    // 🌟 [수정 포인트] 화면에 보이는 전체 readonly 입력창 중 2번째(eq(1))의 달력 아이콘 클릭!
    cy.get('input[type="text"][readonly="readonly"]').filter(':visible').eq(1) .closest('.v-input').find('.material-icons').contains('event').click({ force: true });
    cy.wait(1000);

    cy.get('.menuable__content__active').find('.v-date-picker-header__value button').click({ force: true });
    cy.get('.v-date-picker-table--month').filter(':visible').contains(currentMonthText).click({ force: true });

    // 말일 선택 (계산된 말일 정규식 사용)
    cy.get('.v-date-picker-table').filter(':visible').contains('.v-btn__content', lastDayRegex).closest('.v-btn').click({ force: true });
    cy.get('body').type('{esc}');
    cy.wait(1000);   

    // 검색버튼 클릭 
    cy.get('.v-btn__content').filter(':visible').contains('검색').click({ force: true });
    cy.wait(3000); 


    // 조건 입력 
    //업무시스템 클릭하는 코드 
    cy.get('input[aria-label="업무시스템"]').filter(':visible').closest('.v-input').find('.v-input__slot').click({ force: true });
    cy.wait(500);
    // 업무시스템중 리눅스_배송관리 클릭하는 코드
    cy.get('.v-list__tile__title').contains('리눅스_VIP고객').scrollIntoView().should('be.visible').closest('.v-list__tile').click({ force: true });
    // 선택 후 메뉴 닫기
    cy.get('body').type('{esc}');


    // ==========================================
    // '개인정보' 토글 버튼 완벽 OFF 처리 (네이티브 DOM 클릭)
    // ==========================================
    cy.log('🔘 개인정보 토글 버튼 상태를 확인합니다.');
    cy.get('input[aria-label="개인정보"]').then(($input) => {
      // 현재 상태 확인 (aria-checked 활용)
      const isChecked = $input.attr('aria-checked');
      if (isChecked === 'true') {
        cy.log('⚠️ 현재 토글이 [ON] 상태입니다. 네이티브 DOM 클릭으로 강제 종료합니다!');
        $input[0].click();
        cy.wait(500); // UI 스위치 애니메이션 대기
      } else {
        cy.log('✅ 이미 [OFF] 상태입니다. 아무것도 하지 않고 넘어갑니다.');
      }
    });

    // 검색버튼 클릭 
    cy.get('.v-btn__content').filter(':visible').contains('검색').click({ force: true });
    cy.wait(1000);

    // 접속이력 전체건수 조회
// ==========================================
// 전체 건수 조회 및 팝업 제어
// ==========================================
cy.log('📊 전체 건수 조회를 요청합니다.');

// 1. 메인 화면의 '전체 건수' 버튼 클릭
cy.get('.v-btn__content')
  .filter(':visible')
  .contains('전체 건수')
  .click({ force: true });

// 2. 팝업창이 화면에 뜰 때까지 대기하고 팝업 영역 안으로 진입 (최대 10초 대기)
cy.get('.v-dialog--active', { timeout: 10000 })
  .should('be.visible')
  .within(() => {
      
  
      cy.contains('조회에 많은 시간이 소요될 수 있습니다').should('be.visible');
      
      cy.log('✅ 안내 팝업창 노출 확인 완료. 확인 버튼을 클릭합니다.');

      // 4. 팝업 안의 '확인' 버튼 클릭
      cy.get('.v-btn__content')
        .filter(':visible')
        .contains('확인')
        .click({ force: true });
  });

// 5. 전체 건수 조회 완료 대기 (로딩 스피너 등이 있다면 이곳에 추가 대기 로직 작성)
cy.wait(2000); 
cy.log('🚀 전체 건수 조회 요청 완료!');

// ==========================================
// 6. 조회된 전체 건수 노출 확인 및 데이터 검증
// ==========================================
cy.log('⏳ 서버에서 전체 건수를 집계 중입니다. 잠시 대기합니다...');

// 🌟 [핵심 수정]: contains의 첫 번째 인자에 ':visible'을 바로 넣어줍니다!
// 이렇게 하면 숨겨진 찌꺼기 요소들은 탐색 대상에서 아예 제외됩니다.
cy.contains('div:visible', '전체:', { timeout: 30000 }).invoke('text')
  .then((text) => {
      // 추출된 텍스트 예: "전체: 1,039"
      const cleanText = text.trim();
      cy.log(`👀 화면에 노출된 건수 텍스트: ${cleanText}`);

      // 숫자만 깔끔하게 추출 (예: 1039)
      const totalCount = parseInt(cleanText.replace(/[^0-9]/g, ''), 10);

      // 데이터 정상 조회(0보다 큼) 검증
      expect(
          totalCount, 
          `❌ 전체 건수가 0건이거나 정상적으로 조회되지 않았습니다. (화면 텍스트: ${cleanText})`
      ).to.be.greaterThan(0);

      cy.log(`✅ 전체 건수 조회 완벽 성공! (총 ${totalCount}건 확인됨)`);
      // 🌟 [핵심] 조회한 건수를 'savedCount'라는 이름으로 저장해 둡니다.
      cy.wrap(totalCount).as('savedCount'); 
  });
    
  
   // ==========================================
    // STEP : 점검 대시보드로 현황 상세페이지 이동
    // ==========================================
    
    cy.log('🚀 점검 탭 클릭');
    cy.contains('button', '점검').click({ force: true });
    cy.wait(2000);
    cy.log('--- 화면 검증 시작 ---');

    // 설명: 'v-btn__content' 안에 '검색'이라는 글자가 있고, 눈에 보이는지 확인
    cy.contains('.v-btn__content', '검색').should('exist');
    //검색 버튼 확인
    cy.get('.v-btn__content').filter(':visible').contains('검색').should('be.visible');

  // 업무 시스템 별 개인정보 사용현황 클릭하여 상세페이지로 이동-------------------------------------------
   // 리눅스_배송관리 클릭하기
   // 'apexcharts-legend-text' 클래스를 가진 span 중 첫번쨰 '리눅스_배송관리'를 클릭합니다.
   // 1. 차트 제목을 먼저 찾고, 그 차트를 감싸고 있는 전체 카드(.v-card) 영역으로 올라갑니다.
    cy.contains('.v-card__title', '업무시스템별 개인정보 사용 현황').closest('.v-card') // 🌟 [핵심] 해당 차트의 전체 박스로 시야를 넓힘
     .within(() => {
    
     // 2. 이제 이 블록 안에서는 '해당 차트 내부'만 검색합니다! (다른 차트 간섭 X)
     cy.get('.apexcharts-legend-text').should('be.visible').eq(2).click({ force: true });
   });

   cy.wait(500);
   //팝업창의 본문 내용('상세 페이지로 이동하시겠습니까?')이 맞는지 검증
   cy.contains('p.mb-0:visible', '상세 페이지로 이동하시겠습니까?').should('be.visible');
   cy.wait(500); 
   // 3. 화면에 보이는 '확인' 버튼을 찾아 강제 클릭!
   cy.get('.v-btn__content').filter(':visible').contains('확인').click({ force: true });
   cy.wait(2000);
   // 화면 현황- 업무시스템 별 상세 페이지 이동검증
   cy.get('.tab-btn').contains('업무 시스템 별').closest('button').should('not.have.class', 'inactive');
  


     //현황탭 오류로 임시 주석처리 
    // // ==========================================
    // // STEP : 현황서브메뉴 이동 (개인정보사용현황 건수 확인)
    // // ==========================================
    
    // cy.contains('button', '현황').click({ force: true });
    // cy.wait(2000); // 서브 메뉴가 펼쳐질 시간 대기
    // cy.log('--- 현황 > 정보사용자별 탭 클릭  ---');
    // cy.get('.tab-btn').contains('정보사용자 별').should('be.visible').click({ force: true });
    // cy.log('--- 화면 검증 시작 ---');
    // cy.contains('.c-headline', '검색 조건').should('exist');
    // // 시작날짜 달력 아이콘확인
    // cy.contains('기간').closest('.v-input').find('.material-icons').contains('event').should('be.visible');
    // // 종료날짜 달력 아이콘확인
    // cy.get('input[type="text"][readonly="readonly"]').filter(':visible').eq(1).closest('.v-input').find('.material-icons:contains("event")').should('be.visible');
    //  // 버튼확인
    // cy.get('.v-btn__content').filter(':visible').contains('검색').should('be.visible');
    // //검색 조건 입력문구 확인
    // cy.get('label').filter(':visible').contains('기간').should('be.visible');
    // cy.get('label').filter(':visible').contains('추적 타입').should('be.visible');
    // cy.get('span').filter(':visible').contains('정보 사용자').should('be.visible');
    
    //  cy.log('--- 현황 > 업무시스템 별 탭 클릭  ---');
    // cy.get('.tab-btn').contains('업무 시스템 별').should('be.visible').click({ force: true });
    // cy.wait(3000);
    // cy.log('--- 화면 검증 시작 ---');
    // cy.get('.tab-btn').contains('업무 시스템 별').closest('button').should('not.have.class', 'inactive');
    // // 'c-headline' 클래스를 가진 요소 중에 '파일 다운로드' 글자가 존재하는지 확인
    // cy.contains('.c-headline', '검색 조건').should('exist');
    // // 시작날짜 달력 아이콘확인
    // cy.contains('label', '기간') .closest('.v-input').find('.material-icons').contains('event').should('be.visible');
    // // 종료날짜 달력 아이콘확인
    // cy.get('input[type="text"][readonly="readonly"]').filter(':visible').eq(1).closest('.v-input').find('.material-icons:contains("event")').should('be.visible');
    // // 검색 버튼 확인
    // cy.get('.v-btn__content').filter(':visible').contains('검색').should('be.visible');
    // // 검색조건 입력문구 확인
    // cy.get('input[aria-label="업무시스템"]').filter(':visible').should('be.visible');

    //달력표를 펼침 
    // ==========================================
    // '기간 시작일자' 셋팅 (이번 달 1일)
    // ==========================================
    cy.log(`📅 대상기간 시작일자를 ${currentMonthText} 1일로 셋팅합니다.`);
    //cy.contains('기간').closest('.v-input').find('.material-icons').contains('event').click({ force: true });
     cy.get('input[type="text"][readonly="readonly"]').filter(':visible').eq(0) .closest('.v-input').find('.material-icons').contains('event').click({ force: true });
    cy.wait(1000);

    // 연/월 선택 모드로 변경하여 '이번 달(동적 변수)' 선택
    cy.get('.menuable__content__active').find('.v-date-picker-header__value button').click({ force: true });
    cy.get('.v-date-picker-table--month').filter(':visible').contains(currentMonthText).click({ force: true });

    // 1일 선택
    cy.get('.v-date-picker-table').filter(':visible').contains('.v-btn__content', firstDayRegex).closest('.v-btn').click({ force: true });
    cy.get('body').type('{esc}');
    cy.wait(1000);

    // ==========================================
    // '기간 종료일자' 셋팅 (말일)
    // ==========================================
    cy.log(`📅 대상기간 종료일자를 ${currentMonthText} ${lastDayNum}일로 셋팅합니다.`);
    // 🌟 [수정 포인트] 화면에 보이는 전체 readonly 입력창 중 2번째(eq(1))의 달력 아이콘 클릭!
    cy.get('input[type="text"][readonly="readonly"]').filter(':visible').eq(1) .closest('.v-input').find('.material-icons').contains('event').click({ force: true });
    cy.wait(1000);

    cy.get('.menuable__content__active').find('.v-date-picker-header__value button').click({ force: true });
    cy.get('.v-date-picker-table--month').filter(':visible').contains(currentMonthText).click({ force: true });

    // 말일 선택 (계산된 말일 정규식 사용)
    cy.get('.v-date-picker-table').filter(':visible').contains('.v-btn__content', lastDayRegex).closest('.v-btn').click({ force: true });
    cy.get('body').type('{esc}');
    cy.wait(1000);   

    // 검색버튼 클릭 
    cy.get('.v-btn__content').filter(':visible').contains('검색').click({ force: true });
    cy.wait(3000); 

     


// ==========================================
// 개인정보사용량 차트기반 동적 데이터 추출 및 저장
// ==========================================
cy.log('📊 개인정보 유형별 차트 데이터를 동적으로 추출합니다.');

const chartDataObj = {};

// 🌟 [핵심 수정 1] 화면 전체가 아닌 '첫 번째 차트의 범례 그룹(.apexcharts-legend)'만 콕 집어서 가져옵니다.
cy.get('.apexcharts-legend').eq(0).find('.apexcharts-legend-text').each(($legendInfo, index) => {
    
    const typeName = $legendInfo.text().trim();
    
    // 🌟 [핵심 수정 2] 조각(slice)을 찾을 때도 '첫 번째 차트의 SVG 이미지(.apexcharts-svg)' 안에서만 찾도록 제한합니다.
    cy.get('.apexcharts-svg').eq(0).find(`path.apexcharts-donut-slice-${index}`)
      .invoke('attr', 'data:value')
      .then((val) => {
          const count = parseInt(val, 10);
          chartDataObj[typeName] = count;
          
          cy.log(`🎯 [차트 추출] ${typeName} : ${count}건`);
      });
      
}).then(() => {
    cy.wrap(chartDataObj).as('dynamicChartData');
    cy.log('✅ 첫 번째 차트 데이터 동적 추출 및 저장 완료!');
});


    // ==========================================
    // STEP : 보고 서브메뉴 이동
    // ==========================================
    cy.contains('button', '보고').click({ force: true });
    cy.wait(2000);
    cy.log('--- 화면 검증 시작 ---');
    cy.get('.tab-btn').contains('접속기록 종합 보고서').closest('button').should('not.have.class', 'inactive');
    cy.contains('.c-headline', '보고서 목록').should('exist');
    // v 아이콘 확인하는 코드
    cy.get('.v-icon').filter(':visible').contains('keyboard_arrow_down').should('be.visible');
    // 표 문구열 확인
    cy.get('th').filter(':visible').contains('보고서 이름').should('be.visible');
    cy.get('th').filter(':visible').contains('생성일').should('be.visible');
    cy.get('th').filter(':visible').contains('생성자').should('be.visible');
    cy.get('th').filter(':visible').contains('상태').should('be.visible');
    cy.get('th').filter(':visible').contains('설명').should('be.visible');
    cy.get('th').filter(':visible').contains('삭제').should('be.visible');

    // ==========================================
    // 페이지수 5-> 25 개 옵션 변경 
    // ==========================================
    // 1. 엉뚱한 화살표 대신, 화면 하단에 '5'라고 적혀있는 페이지 선택 박스를 콕 집어 클릭합니다.
    cy.contains('.v-select__selection', '5').click({ force: true });
    cy.wait(1000); // 콤보박스 메뉴가 스르륵 열릴 때까지 대기
    // 2. 열린 메뉴(.v-menu__content) 안에서 '25'을 찾아서 클릭합니다.
    // (클래스명에 얽매이지 않고 텍스트 '25'을 포함한 요소를 강제 클릭하도록 유연하게 작성)
    cy.get('.v-menu__content').filter(':visible').contains('25') .click({ force: true });
    // 3. 목록이 25개로 갱신될 시간을 넉넉히 줍니다.
    cy.wait(3000);

    // ==========================================
    // 기존 잔여정책이 존재한다면 삭제  
    // ==========================================
    // Depth통계확인_auto 가 여러개 존재한다면 다 삭제하도록 코드-----------------------------------
    // 1. 반복 삭제를 수행할 함수를 정의합니다.
     const deleteAllReports = () => {
       // body 전체를 가져와서 동기적으로 검사합니다.
       cy.get('body').then(($body) => {
         // 만약 화면(행)에 'Depth검증용 보고서_auto'라는 글자가 1개라도 남아있다면?
         if ($body.find('tr:contains("Depth통계확인_auto")').length > 0) {
      
           // --- [삭제 로직 시작] ---
           // 가장 위에 있는 'Depth검증용 보고서_auto' 행을 찾아서 휴지통 클릭
           cy.contains('tr', 'Depth통계확인_auto').find('.fa-trash').closest('button').then(($btn) => {
                 $btn[0].click(); // [필살기] 강제 클릭
             });

           // 삭제 확인 팝업 처리
           cy.contains('삭제하시겠습니까?').should('be.visible');
           cy.wait(500); // 팝업 애니메이션 안정화 대기
      
           cy.get('.v-btn__content').filter(':visible').contains('확인').click({ force: true });
           // 삭제 후 목록이 갱신될 시간을 잠깐 줍니다.
           cy.wait(1000);

           // --- [삭제 로직 끝] --
           // 중요! 다 지웠는지 확인하기 위해 자기 자신을 다시 호출합니다. (재귀)
           deleteAllReports();
      
          } else {
           // 더 이상 'Depth통계확인_auto'가 없다면 로그를 남기고 종료합니다.
            cy.log('모든 중복 Depth통계확인_auto 삭제 완료!');
         }
       });
     };
      cy.wait(4000);
      // 2. 정의한 함수를 실행합니다.
      deleteAllReports();

      // 3. 마지막으로 정말 다 사라졌는지 최종 검증합니다.
      cy.contains('a', 'Depth검증용 보고서_auto').should('not.exist');
      cy.wait(1000);
      //-----------------------------------------------------------------------------------

    // ==========================================
    // 보고서 셋팅 : 추가하기 - 월 정기점검 보고서 
    // ==========================================
 
    // 보고서 추가하기 - 동그란 플러스 버튼 클릭 
    cy.get('.grid-add-button').should('exist').then(($btn) => {
        $btn[0].click(); 
           });    
    cy.wait(1000);

    // 보고서 추가화면에서 보고서이름 입력
    cy.get('input[aria-label="보고서 이름"]').filter(':visible').first().clear({ force: true }).type('Depth통계확인_auto', { force: true });
    cy.wait(1000);
    // 보고서 추가화면에서 보고서설명 작성 
    cy.get('input[aria-label="설명"]').filter(':visible').first().clear({ force: true }).type('통계확인용 보고서입니다.', { force: true });
    cy.wait(1000);
    
    // 보고서 추가화면에서 보고서 종류 선택 - 월 정기점검 보고서
    //보고서 종류 콤보박스 열기 
    cy.get('input[aria-label="보고서 종류"]').closest('.v-input').find('.v-input__slot').click({ force: true });
    cy.wait(1000);
    // 보고서 종류 콤보박스에서  '월 정기점검 보고서 (행위_Mongo)' 선택하는 코드
    cy.get('.v-menu__content').filter(':visible').contains('.v-list__tile__title', '월 정기점검 보고서').should('be.visible').click({ force: true });
    cy.wait(1000);
    cy.get('body').type('{esc}');
    cy.wait(500);

    // 보고서 추가화면에서 업무시스템 - 리눅스_배송관리 선택
    cy.get('input[aria-label="업무시스템"]').closest('.v-input__slot').click({ force: true });
    // 업무시스템중 리눅스_배송관리 클릭하는 코드
    cy.get('.v-menu__content').filter(':visible').find('.v-list__tile__title').contains('리눅스_VIP고객').scrollIntoView().click({ force: true });          
    cy.wait(1000);
    // 검색조건 클릭하여 선택한 컨텍스트 메뉴 닫기
    cy.get('body').type('{esc}');

    // 아래 확장자별 검색이있으므로 디폴트값 pdf로진행
    // //확장자 종류 - html 선택  
    // // 디폴트값 확인을 위한  PDF클릭
    // cy.get('span[title="pdf"]').should('be.visible').click({ force: true }); 
    // //cy.get('input[aria-label="확장자"]').closest('.v-input').find('.v-input__slot').click({ force: true });
    // cy.wait(500);
    
    // // 확장자 콤보박스에서 html 선택
    // cy.contains('.v-list__tile__title', 'html').click({ force: true });
    // cy.wait(500);

// ==========================================
// 1. 대상기간 '시작일자' 셋팅 (1일)
// ==========================================
cy.log(`📅 대상기간 시작일자를 ${currentMonthText} 1일로 셋팅합니다.`);

cy.get('input[aria-label="대상기간 시작일자"]').closest('.v-input').find('.material-icons').contains('event').click({ force: true });
cy.wait(500);

// 연/월 선택 모드로 변경하여 '이번 달(동적 변수)' 선택
cy.get('.menuable__content__active').find('.v-date-picker-header__value button').click({ force: true });
cy.get('.v-date-picker-table--month').filter(':visible').contains(currentMonthText).click({ force: true });

// 1일 선택
cy.get('.v-date-picker-table').filter(':visible').contains('.v-btn__content', firstDayRegex).closest('.v-btn').click({ force: true });
cy.get('body').type('{esc}');
cy.wait(500);

// ==========================================
// 2. 대상기간 '종료일자' 셋팅 (말일)
// ==========================================
cy.log(`📅 대상기간 종료일자를 ${currentMonthText} ${lastDayNum}일로 셋팅합니다.`);

cy.get('input[aria-label="대상기간 종료일자"]').closest('.v-input').find('.material-icons').last().contains('event').click({ force: true });
cy.wait(500);

 // 🌟 [핵심 추가] 하단 코드에도 '월(Month)'을 이전 달로 변경하는 로직을 삽입합니다.
cy.get('.menuable__content__active').find('.v-date-picker-header__value button').click({ force: true });
cy.get('.v-date-picker-table--month').filter(':visible').contains(currentMonthText).click({ force: true });

// 말일 선택 (계산된 말일 정규식 사용)
cy.get('.v-date-picker-table').filter(':visible').contains('.v-btn__content', lastDayRegex).closest('.v-btn').click({ force: true });
cy.get('body').type('{esc}');
cy.wait(500);


// 저장버튼 클릭 
cy.get('.v-btn__content').filter(':visible').contains('저장').click({ force: true });
cy.wait(5000);

//보고서 목록에서 추가한 보고서 클릭하여 열기
cy.contains('a', 'Depth통계확인_auto').click({ force: true });
cy.wait(1000);

// ==========================================
// [보고서 화면] 오즈 뷰어 데이터 추출 및 비교 검증
// ==========================================
cy.log('📄 보고서 화면 진입 완료. 오즈 뷰어 데이터 정합성 검증을 시작합니다.');

// 1. 오즈 보고서가 렌더링될 때까지 충분히 대기합니다. (보고서 생성 시간 고려)
cy.wait(5000); 

// 2. 아까 저장해 둔 'savedCount' 값을 꺼내옵니다.
cy.get('@savedCount').then((uiCount) => {
    
    // 3. 오즈 뷰어 iframe 내부로 접근합니다.
    // 💡 (주의) 실제 프로젝트의 iframe ID나 클래스명으로 변경해 주세요! (예: iframe#oz_viewer)
   // ... 앞부분 생략 (cy.get('@savedCount').then(...) 등) ...

    cy.get('iframe', { timeout: 15000 })
      .its('0.contentDocument.body').should('not.be.empty')
      .then(cy.wrap)
      .within(() => {
          
          // =====================================================
          // 🌟 1. '한 페이지 다음으로 이동' 화살표 버튼 클릭 (2페이지로!)
          // =====================================================
          cy.log('➡️ 다음 페이지(2페이지)로 화살표 버튼을 눌러 이동합니다.');
          
          // 올려주신 HTML의 class('btnNEXT') 또는 title 속성을 활용하여 정확히 타겟팅합니다.
          cy.get('input.btnNEXT[title="한 페이지 다음으로 이동"]').click({ force: true });
          // 2페이지가 화면에 그려질 수 있도록 충분히 대기합니다.
          cy.wait(2000); 
          // =====================================================

        // =====================================================
      // 🌟 2. 보고서 텍스트 전체 접속기록이력 추출 및 정규식 분석
      // =====================================================
      cy.log('🔎 보고서 내부의 텍스트를 분석하여 데이터를 추출합니다.');

      // 🌟 [핵심 수정] cy.get('body') 대신 cy.root()를 사용합니다!
      // (현재 within으로 잡고 있는 iframe의 body 전체를 의미합니다)
      cy.root().invoke('text').then((bodyText) => {
          
          // 띄어쓰기, 줄바꿈 등을 하나의 공백으로 깔끔하게 정리합니다.
          const cleanText = bodyText.replace(/\s+/g, ' ');

          // 정규식(Regex)을 이용해 '이번 달' 건수 추출
          const regex = /전체 접속기록\s*\(\s*총\s*건수\s*\)\s+[0-9,]+\s+([0-9,]+)/;
          const match = cleanText.match(regex);

          if (match && match[1]) {
              const extractedReportCount = parseInt(match[1].replace(/,/g, ''), 10);
              cy.log(`📊 [데이터 추출 성공] 오즈 뷰어 이번 달 전체 접속기록: ${extractedReportCount}건`);

              // =====================================================
              // 🌟 3. 최종 정합성 비교 검증
              // =====================================================
              cy.get('@savedCount').then((uiCount) => {
                  expect(
                      uiCount, 
                      `데이터 일치 조회중! (이력 건수: ${uiCount}건 vs 보고서: ${extractedReportCount}건)`
                  ).to.equal(extractedReportCount);
                  
                  cy.log('🎉 데이터 직접 추출 및 정합성 검증 완벽 일치 통과!');
              });

          } else {
              throw new Error('❌ 보고서에서 "전체 접속기록" 데이터를 추출하지 못했습니다.');
          }
      });
  });
});


// ============================================================
// 🌟 3. 보고서 화면 개인정보사용량 데이터 추출 및 동적 일괄 검증
// ============================================================
// 1. 앞에서 저장해 둔 동적 차트 데이터 객체를 꺼내옵니다.
cy.get('@dynamicChartData').then((chartData) => {
    
    // 오즈 뷰어 iframe 진입 (기존 코드와 동일)
    cy.get('iframe', { timeout: 15000 })
      .its('0.contentDocument.body').should('not.be.empty')
      .then(cy.wrap)
      .within(() => {
          
          cy.log('🔎 보고서 내부 텍스트를 분석하여 항목별로 데이터를 검증합니다.');

          // iframe 내의 전체 텍스트를 가져와서 공백을 정리합니다.
          cy.root().invoke('text').then((bodyText) => {
              const cleanText = bodyText.replace(/\s+/g, ' ');

              // 2. Object.keys()를 이용해 저장된 데이터의 항목 이름(Key)들을 하나씩 순회합니다.
              Object.keys(chartData).forEach((typeName) => {
                  
                  // 차트에서 가져온 기대 건수 (예: 42435)
                  const expectedCount = chartData[typeName];
                  
                  // =====================================================
                  // 🌟 [핵심 추가] 차트와 보고서 명칭 불일치 예외 처리
                  // =====================================================
                  let searchName = typeName;
                  if (typeName === '조합등록번호') {
                      searchName = '조합주민번호';
                      cy.log(`⚠️ [예외 처리] 차트 명칭 "${typeName}" -> 보고서 명칭 "${searchName}" 매핑`);
                  }
                  
                  // 🌟 typeName 대신 searchName을 이스케이프 처리하여 정규식에 반영
                  const safeTypeName = searchName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
                  
                  // 🌟 [동적 정규식] '항목명 + (지난달)숫자 건 + (이번달)숫자 건' 패턴을 찾습니다.
                  const regex = new RegExp(`(?:^|\\s)${safeTypeName}\\s+[0-9,]+\\s*건\\s+([0-9,]+)\\s*건`);
                  const match = cleanText.match(regex);

                  if (match && match[1]) {
                      // 추출된 문자열에서 콤마를 제거하고 순수 숫자로 변환합니다.
                      const reportCount = parseInt(match[1].replace(/,/g, ''), 10);
                      
                      // 3. 차트 건수와 보고서 건수를 비교합니다!
                      expect(
                          expectedCount, 
                          ` [${typeName}] 데이터 비교단계 (차트: ${expectedCount}건 vs 보고서: ${reportCount}건)`
                      ).to.equal(reportCount);
                      
                      cy.log(`✅ [검증 통과] ${typeName}: ${reportCount}건 일치!`);

                  } else {
                      // 항목을 아예 찾지 못했을 경우의 에러 처리 (searchName 출력)
                      throw new Error(`❌ 보고서에서 "${searchName}" 항목을 찾을 수 없거나 데이터 구조가 다릅니다.`);
                  }
              });
              
              cy.log('🎉 [최종 통과] 모든 개인정보 유형의 데이터 정합성 검증이 완벽하게 일치합니다!');
          });
      });
});
   
    // ==========================================
    // [FINAL] 테스트 종료 및 메뉴 닫기
    // ==========================================
    cy.log('🎉 접속기록이력 전체건수 - 보고서 통계확인 테스트 시나리오 성공적으로 완료!');
    cy.get('body').type('{esc}');
    cy.get('body').click('center', { force: true });

  });
});  

//코드마지막


 })()
;
