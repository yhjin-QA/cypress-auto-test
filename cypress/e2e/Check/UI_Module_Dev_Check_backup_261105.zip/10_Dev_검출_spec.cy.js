/**코드 시작  */
describe('로그캐치 사이트 테스트', () => {

  // ▼ 1. 모든 에러 무시 설정 (강력한 방어막) ▼
  Cypress.on('uncaught:exception', (err, runnable) => {
    // 무시할 에러 메시지 목록
    const ignoredErrors = [
      'Navigation cancelled',
      'Cannot read properties',
      'resetValidation',
      'NavigationDuplicated', // [NEW] 중복 이동 에러 무시 추가
      'Redirected when going from',
      'navigation guard',
      'Avoided redundant navigation',
      'Loading chunk',
      'Loading CSS chunk',
      'operate.task.packageManagement',
      'e is not defined',
      'Script error',
      'not valid JSON'
    ];

    // 위 목록 중 하나라도 포함되면 에러를 무시함
    if (ignoredErrors.some(e => err.message.includes(e))) {
      return false;
    }
  });


  it('로그캐치 UI기본체크', () => {

    // ==========================================
    // STEP 1: 로그인
    // ==========================================
    // 1. 사이트 방문
    cy.visit('https://10.10.54.51:18443/logcatch/login');
    cy.wait(4000); // 로딩 대기

    ////////////새로고침코드//////
    cy.get('body').then(($body) => {
      // 만약 입력창이 안 보인다면? (흰 화면 상태라면?)
      if ($body.find('input[aria-label="사용자 계정"]').length === 0) {
        cy.log('🔴 화면 렌더링 실패 감지! 페이지를 새로고침합니다.');
        cy.reload();
        cy.wait(2000);
      } else {
        cy.log('🟢 화면이 정상적으로 로드되었습니다.');
      }
    });
    //////////////////////////////////////

    // 2. 아이디 입력
    cy.get('input[aria-label="사용자 계정"]').should('exist').type('admin', { force: true });

    // 3. 비밀번호 입력
    cy.get('input[aria-label="패스워드"]').should('exist').type('Manager1!', { force: true });

    // 4. 로그인 실행 (버튼 클릭 대신 엔터키 사용)
    cy.get('input[aria-label="패스워드"]').type('{enter}', { force: true });

    // -----------------------------------------------------------
    // "이미 로그인" 알림창 처리 (조건부 로직)
    // -----------------------------------------------------------
    cy.wait(2000);
    cy.get('body').then(($body) => {
      if ($body.find('.v-card__title:contains("이미 접속 중인 계정입니다."):visible').length > 0) {
        cy.log('⚠️ 알림창 발견! 확인 버튼을 클릭합니다.');
        cy.contains('.v-card__title', '이미 접속 중인 계정입니다.')
          .closest('.v-card')
          .contains('확인')
          .click();
        cy.wait(1000);
      } else {
        cy.log('✅ 알림창이 없습니다. 넘어갑니다.');
      }
    });

    // 5. 로그인 성공 검증 (URL 변경 확인)
    cy.url({ timeout: 10000 }).should('not.include', '/login');

    // 6. 화면 안정화 대기
    cy.wait(3000);
    // 로그인 성공


    // ==========================================
    // 검출탭 > 필터 서브메뉴 선택
    // ==========================================
    cy.log('🚀 검출탭 > 필터  서브메뉴 선택 ');
    cy.contains('button', '검출').should('be.visible').click({ force: true });
    cy.wait(2000);
    cy.log('---검출 - 필터 서브메뉴 클릭 ---');
    cy.get('.v-list__tile__title').filter(':contains("필터")').filter(':visible').click({ force: true });
    cy.wait(3000);


    // 검출탭 > 필터 > 전처리 파일 구분 설정 탭 클릭
    cy.log('--- 전처리 파일 구분 설정 탭 클릭 ---');
    cy.contains('.v-btn__content', '전처리 파일 구분 설정').should('be.visible').click({ force: true });
    cy.wait(2000);
    cy.log('--- 화면 검증 시작 ---');
    // 트리영역 + 아이콘
    cy.get('.v-icon.fa-plus').filter(':visible').should('be.visible');
    // 트리영역 새로고침 아이콘
    cy.get('.material-icons').filter(':visible').contains('autorenew').should('be.visible');
    cy.contains('.c-headline', '전처리 파일 구분 설정').should('exist');
    // 2.9.1.262_r35274 문구 수정 정책이름 -> 정책명
    cy.get('input[aria-label="정책명"]').filter(':visible').should('be.visible');
    cy.get('input[aria-label="기본 확장자"]').filter(':visible').should('be.visible');

    // [신규] 파일 다운로드 대상 구분 유형 콤보박스 (기본값: ContentType)
    cy.get('input[aria-label="파일 다운로드 대상 구분 유형"]').filter(':visible').should('be.visible').and('have.attr', 'role', 'combobox');
    cy.contains('.v-select__selections span', 'ContentType').filter(':visible').should('be.visible');
    cy.get('input[aria-label="ContentType Value"]').filter(':visible').should('be.visible');

    // [신규] 파일 다운로드 파일 명 구분 유형 콤보박스 (기본값: ContentDisposition)
    cy.get('input[aria-label="파일 다운로드 파일 명 구분 유형"]').filter(':visible').should('be.visible').and('have.attr', 'role', 'combobox');
    cy.contains('.v-select__selections span', 'ContentDisposition').filter(':visible').should('be.visible');
    cy.get('input[aria-label="ContentDisposition Key"]').filter(':visible').should('be.visible');
    cy.log('✅ 검출 - 필터 - [전처리 파일 구분 설정] 출력 확인 완료! ');


    // 검출탭 > 필터 > 전처리 필터링 정책 탭 클릭
    cy.log('--- 전처리 필터링 정책 탭 클릭 ---');
    cy.contains('.v-btn__content', '전처리 필터링 정책').should('be.visible').click({ force: true });
    cy.wait(2000);

    // 검출 > 필터 > 전처리 필터링 정책 > [사용자 IP 제외] 탭선택
    cy.contains('.v-tabs__item', '사용자 IP 제외').click({ force: true });
    cy.wait(2000);
    cy.log('--- 화면 검증 시작 ---');
    cy.contains('.c-headline', 'Excluded IP').should('exist');
    cy.get('p').filter(':visible').contains('IP not covered by Logcollector').should('be.visible');

    cy.contains('.c-headline', 'IP').should('exist');
    cy.get('label[for="ipv4-address"]').should('contain', 'IP').and('be.visible');
    cy.get('input[aria-label="설명"]').filter(':visible').should('be.visible');
    cy.get('input[aria-label="업무시스템 할당"]').filter(':visible').should('be.visible');
    cy.get('input[aria-label="Log Tracer"]').filter(':visible').should('be.visible');
    cy.get('.v-btn__content').filter(':visible').contains('저장').should('be.visible');

    cy.contains('.c-headline', '등록 필터 상세 보기').should('exist');
    cy.get('th').filter(':visible').contains('IP').should('be.visible');
    cy.get('th').filter(':visible').contains('설명').should('be.visible');
    cy.get('th').filter(':visible').contains('업무시스템').should('be.visible');
    cy.get('th').filter(':visible').contains('Log Tracer').should('be.visible');
    cy.get('th').filter(':visible').contains('삭제').should('be.visible');

    cy.contains('.c-headline', '변경 이력').should('exist');
    cy.get('th').filter(':visible').contains('발생 일시').should('be.visible');
    cy.get('th').filter(':visible').contains('관리자').should('be.visible');
    // IP문구 중복으로 구분처리
    cy.get('th').filter(':visible').filter(':contains("IP")').eq(1).should('be.visible');
    // 2.9.1.262_r35274 문구 수정 "상태" -> "조건"
    cy.get('th').filter(':visible').contains('조건').should('be.visible');
    cy.log('✅ 검출 - 필터 - 전처리 필터링 정책 - [사용자 IP 제외] 탭 클릭 및 출력 확인 완료');


    // 검출탭 > 필터 > 전처리 필터링 정책 > [화면URI제외] 탭선택
    cy.contains('.v-tabs__item', '화면 (URI) 제외').should('be.visible').click({ force: true });
    cy.wait(2000);
    cy.log('--- 화면 검증 시작 ---');
    cy.contains('.v-tabs__item--active', '화면 (URI) 제외').should('exist');
    cy.contains('.c-headline', 'Excluded IP').should('exist');
    cy.get('p').filter(':visible').contains('URI not covered by Logcollector').should('be.visible');

    cy.contains('.c-headline', '화면 URI').should('exist');
    cy.get('input[aria-label="화면 URI"]').filter(':visible').should('be.visible');
    cy.get('input[aria-label="설명"]').filter(':visible').should('be.visible');
    cy.get('input[aria-label="업무시스템 할당"]').filter(':visible').should('be.visible');
    cy.get('input[aria-label="Log Tracer"]').filter(':visible').should('be.visible');
    cy.get('.v-btn__content').filter(':visible').contains('저장').should('be.visible');

    cy.contains('.c-headline', '등록 필터 상세 보기').should('exist');
    cy.get('th').filter(':visible').contains('화면 URI').should('be.visible');
    cy.get('th').filter(':visible').contains('설명').should('be.visible');
    cy.get('th').filter(':visible').contains('업무시스템').should('be.visible');
    cy.get('th').filter(':visible').contains('Log Tracer').should('be.visible');
    cy.get('th').filter(':visible').contains('삭제').should('be.visible');

    cy.contains('.c-headline', '변경 이력').should('exist');
    cy.get('th').filter(':visible').contains('발생 일시').should('be.visible');
    cy.get('th').filter(':visible').contains('관리자').should('be.visible');
    cy.get('th').filter(':visible').contains('IP').should('be.visible');
    // 2.9.1.262_r35274 문구 수정 "상태" -> "조건"
    cy.get('th').filter(':visible').contains('조건').should('be.visible');
    cy.log('✅ 검출 - 필터 - 전처리 필터링 정책 - [화면 (URI) 제외] 탭 클릭 및 출력 확인 완료');


    // 검출탭 > 필터 > 전처리 필터링 정책 > [특정SQL 제외] 탭선택
    cy.contains('.v-tabs__item', '특정 SQL 제외').should('be.visible').click({ force: true });
    cy.wait(2000);
    cy.log('--- 화면 검증 시작 ---');
    cy.contains('.v-tabs__item--active', '특정 SQL 제외').should('exist');
    cy.contains('.c-headline', 'Excluded IP').should('exist');
    cy.get('p').filter(':visible').contains('SQL not covered by Logcollector').should('be.visible');

    cy.contains('.c-headline', '특정 SQL').should('exist');
    cy.get('input[aria-label="특정 SQL"]').filter(':visible').should('be.visible');
    cy.get('input[aria-label="설명"]').filter(':visible').should('be.visible');
    cy.get('input[aria-label="업무시스템 할당"]').filter(':visible').should('be.visible');
    cy.get('input[aria-label="Log Tracer"]').filter(':visible').should('be.visible');
    cy.get('.v-btn__content').filter(':visible').contains('저장').should('be.visible');

    cy.contains('.c-headline', '등록 필터 상세 보기').should('exist');
    cy.get('th').filter(':visible').contains('특정 SQL').should('be.visible');
    cy.get('th').filter(':visible').contains('설명').should('be.visible');
    cy.get('th').filter(':visible').contains('업무시스템').should('be.visible');
    cy.get('th').filter(':visible').contains('Log Tracer').should('be.visible');
    cy.get('th').filter(':visible').contains('삭제').should('be.visible');

    cy.contains('.c-headline', '변경 이력').should('exist');
    cy.get('th').filter(':visible').contains('발생 일시').should('be.visible');
    cy.get('th').filter(':visible').contains('관리자').should('be.visible');
    cy.get('th').filter(':visible').contains('IP').should('be.visible');
    // 2.9.1.262_r35274 문구 수정 "상태" -> "조건"
    cy.get('th').filter(':visible').contains('조건').should('be.visible');
    cy.log('✅ 검출 - 필터 - 전처리 필터링 정책 - [특정 SQL 제외] 탭 클릭 및 출력 확인 완료');


    // 검출탭 > 필터 > 전처리 필터링 정책 > [CONTENT-TYPE 제외] 탭선택
    cy.contains('.v-tabs__item', 'Content-Type 제외').should('be.visible').click({ force: true });
    cy.wait(2000);
    cy.log('--- 화면 검증 시작 ---');
    cy.contains('.v-tabs__item--active', 'Content-Type 제외').should('exist');
    cy.contains('.c-headline', 'Excluded Content-Type').should('exist');
    cy.get('p').filter(':visible').contains('Content-Type not covered by Logcollector').should('be.visible');

    cy.contains('.c-headline', 'Content-Type 제외').should('exist');
    // 2.9.1.262_r35274 하이픈 제거 됨. Content-Type -> Content Type
    cy.get('input[aria-label="Content Type"]').filter(':visible').should('be.visible');
    cy.get('input[aria-label="설명"]').filter(':visible').should('be.visible');
    cy.get('input[aria-label="업무시스템 할당"]').filter(':visible').should('be.visible');
    cy.get('input[aria-label="Log Tracer"]').filter(':visible').should('be.visible');
    cy.get('.v-btn__content').filter(':visible').contains('저장').should('be.visible');

    cy.contains('.c-headline', '등록 필터 상세 보기').should('exist');
    // 표 열 첫번째 문구없음.
    cy.get('th').filter(':visible').contains('설명').should('be.visible');
    cy.get('th').filter(':visible').contains('업무시스템').should('be.visible');
    cy.get('th').filter(':visible').contains('Log Tracer').should('be.visible');
    cy.get('th').filter(':visible').contains('삭제').should('be.visible');

    cy.contains('.c-headline', '변경 이력').should('exist');
    cy.get('th').filter(':visible').contains('발생 일시').should('be.visible');
    cy.get('th').filter(':visible').contains('관리자').should('be.visible');
    cy.get('th').filter(':visible').contains('IP').should('be.visible');
    // 2.9.1.262_r35274 문구 수정 "상태" -> "조건"
    cy.get('th').filter(':visible').contains('조건').should('be.visible');
    cy.log('✅ 검출 - 필터 - 전처리 필터링 정책 - [Content-Type 제외] 탭 클릭 및 출력 확인 완료');
    cy.log('✅ 검출 - 필터 - [전처리 필터링 정책] 출력 확인 완료! ');


    // 검출탭 > 필터 > 전처리 사용자 계정 탐색 설정 탭 클릭
    cy.log('--- 전처리 사용자 계정 탐색 설정 탭 클릭 ---');
    cy.contains('.v-btn__content', '전처리 사용자 계정 탐색 설정').should('be.visible').click({ force: true });
    cy.wait(2000);
    cy.log('--- 화면 검증 시작 ---');
    cy.get('.v-icon.fa-plus').filter(':visible').should('be.visible');
    cy.get('.material-icons').filter(':visible').contains('autorenew').should('be.visible');
    cy.contains('.c-headline', '전처리 사용자 계정 탐색 설정').should('exist');
    // 2.9.1.262_r35274 정책 이름 -> 정책명 문구수정
    cy.get('input[aria-label="정책명"]').filter(':visible').should('be.visible');
    cy.get('span[title="Request Header Cookie"]').should('be.visible');
    cy.get('input[aria-label="key"]').filter(':visible').should('be.visible');
    cy.get('input[aria-label="Log Tracer"]').filter(':visible').should('be.visible');
    cy.get('input[aria-label="업무시스템 할당"]').filter(':visible').should('be.visible');
    cy.log('✅ 검출 - 필터 - [전처리 사용자 계정 탐색 설정] 화면 출력 확인 완료 ');


    // 검출탭 > 필터 > 전처리 디코더 설정 탭 클릭
    cy.log('--- 전처리 디코더 설정 탭 클릭 ---');
    cy.contains('.v-btn__content', '전처리 디코더 설정').should('be.visible').click({ force: true });
    cy.wait(2000);
    cy.log('--- 화면 검증 시작 ---');
    cy.get('.v-icon.fa-plus').filter(':visible').should('be.visible');
    cy.get('.material-icons').filter(':visible').contains('autorenew').should('be.visible');
    cy.contains('.c-headline', '전처리 디코더 설정').should('exist');
    // 2.9.1.262_r35274 정책이름 -> 정책명 문구 수정
    cy.get('input[aria-label="정책명"]').filter(':visible').should('be.visible');
    cy.get('span[title="URL Decoder"]').should('be.visible');
    cy.get('span[title="Response Body(UTF-8)"]').should('be.visible');
    cy.get('input[aria-label="Log Tracer"]').filter(':visible').should('be.visible');
    cy.get('input[aria-label="업무시스템 할당"]').filter(':visible').should('be.visible');
    cy.get('input[aria-label="URI"]').filter(':visible').should('be.visible');
    cy.log('✅ 검출 - 필터 - [전처리 디코더 설정] 화면 출력 확인 완료 ');


    // v3.0.4.0_R34865 추가 메뉴
    // 검출탭 > 필터 > 전처리 인코더 설정 탭 클릭
    cy.log('--- 전처리 인코더 설정 탭 클릭 ---');
    cy.contains('.v-btn__content', '전처리 인코더 설정').should('be.visible').click({ force: true });
    cy.wait(2000);
    cy.log('--- 화면 검증 시작 ---');
    cy.get('.v-icon.fa-plus').filter(':visible').should('be.visible');
    cy.get('.material-icons').filter(':visible').contains('autorenew').should('be.visible');
    cy.contains('.c-headline', '설정').should('exist');
    // 2.9.1.262_r35274 정책이름 -> 정책명 문구수정
    cy.get('input[aria-label="정책명"]').filter(':visible').should('be.visible');
    cy.get('input[aria-label="Log Tracer"]').should('be.visible').and('have.attr', 'type', 'text').and('have.attr', 'role', 'combobox');
    cy.get('input[aria-label="URI"]').should('be.visible').and('be.enabled').and('have.attr', 'type', 'text').and('have.attr', 'role', 'combobox');
    cy.get('input[aria-label="Charset ( 대소문자 및 빈공간 유의 )"]').should('be.visible').and('have.attr', 'type', 'text');
    cy.get('.v-btn__content').filter(':visible').contains('저장').should('be.visible');
    cy.log('✅ 검출 - 필터 - [전처리 인코더 설정] 화면 출력 확인 완료 ');


    // v3.0.4.0_R34865 추가 메뉴
    // 검출탭 > 필터 > 식별자 패턴 관리 탭 클릭
    cy.log('--- 식별자 패턴 관리 탭 클릭 ---');
    cy.contains('.v-btn__content', '식별자 패턴 관리').should('be.visible').click({ force: true });
    cy.wait(2000);
    cy.log('--- 화면 검증 시작 ---');
    cy.get('.v-icon.fa-plus').filter(':visible').should('be.visible');
    cy.get('.material-icons').filter(':visible').contains('autorenew').should('be.visible');
    cy.get('.v-icon.fa-search').filter(':visible').should('be.visible');

    // 타이틀 문구확인
    cy.contains('span.title', '식별자').should('be.visible').and('have.class', 'font-weight-bold');

    // 트리영역 폴더 문구확인
    cy.contains('label.text-label', '식별자 패턴 그룹').should('exist');
    cy.contains('label.text-label', 'Pattern Korea').should('exist');
    cy.contains('label.text-label', 'Pattern Korea2').should('exist');

    // 컬럼 정렬 상태 확인
    cy.contains('th.column.sortable', '개인정보 유형').should('be.visible').and('have.class', 'asc');
    cy.contains('th.column.sortable', '식별자 패턴').should('be.visible').and('have.class', 'asc');

    cy.log('✅ 검출 - 필터 - [식별자 패턴관리] 화면 출력 확인 완료 ');


    ////////////////////////////////////////
    // 검출탭 > 검출 메뉴 관리 서브메뉴 선택
    ///////////////////////////////////////
    cy.log('🚀 검출 탭 > 검출 메뉴 관리 서브메뉴 선택 ');
    cy.contains('button', '검출').should('be.visible').click({ force: true });
    cy.wait(2000);
    cy.get('.v-list__tile__title').filter(':contains("검출 메뉴 관리")').filter(':visible').click({ force: true });
    cy.wait(3000);

    // 검출탭 > 검출 메뉴 관리 > 메뉴관리 선택 --------------------------------------------------
    cy.contains('.v-btn__content', '메뉴 관리').click({ force: true });
    cy.log('--- 화면 검증 시작 ---');
    cy.contains('.c-headline', '검색 조건').should('exist');
    cy.get('input[aria-label="업무시스템"]').filter(':visible').should('be.visible');
    cy.get('input[aria-label="HTTP Method"]').filter(':visible').should('be.visible');
    cy.get('input[aria-label="URI 주소"]').filter(':visible').should('be.visible');
    cy.get('.v-label').filter(':visible').contains('메뉴 등록 필요').should('be.visible');
    cy.get('.v-label').filter(':visible').contains('오탐/확정').should('be.visible');

    // 3.0.3.0_R34785 에서 파일 선택 버튼식으로 변경
    cy.get('.v-btn__content').filter(':visible').contains('들여오기').should('be.visible');
    cy.get('.v-btn__content').filter(':visible').contains('파일 선택').should('be.visible');
    cy.get('.v-btn__content').filter(':visible').contains('엑셀 다운로드').should('be.visible');
    cy.get('.v-btn__content').filter(':visible').contains('검색').should('be.visible');

    cy.get('th').filter(':visible').contains('발견 일시').should('be.visible');
    cy.get('th').filter(':visible').contains('업무시스템').should('be.visible');
    cy.get('th').filter(':visible').contains('URI 주소').should('be.visible');
    cy.get('th').filter(':visible').contains('접속 메뉴').should('be.visible');
    cy.get('th').filter(':visible').contains('행위 유형').should('be.visible');
    cy.get('th').filter(':visible').contains('HTTP Method').should('be.visible');
    cy.get('th').filter(':visible').contains('처리').should('be.visible');
    cy.log('✅ 검출 - 검출메뉴관리 - [메뉴 관리] 출력 확인 완료 ');


    // 검출탭 > 검출 메뉴 관리 > URI 관리 선택 --------------------------------------------------
    cy.contains('.v-btn__content', 'URI 관리').should('be.visible').click({ force: true });
    cy.wait(3000);
    cy.log('--- 화면 검증 시작 ---');
    cy.contains('.c-headline', '검색 조건').should('exist');
    cy.get('input[aria-label="업무시스템"]').filter(':visible').should('be.visible');
    cy.get('input[aria-label="HTTP Method"]').filter(':visible').should('be.visible');
    cy.get('input[aria-label="URI 주소"]').filter(':visible').should('be.visible');
    cy.get('.v-label').filter(':visible').contains('등록된 URI').should('be.visible');
    cy.get('.v-btn__content').filter(':visible').contains('검색').should('be.visible');
    cy.get('th').filter(':visible').contains('업무시스템').should('be.visible');
    cy.get('th').filter(':visible').contains('HTTP Method').should('be.visible');
    cy.get('th').filter(':visible').contains('수집된 URI').should('be.visible');
    cy.get('th').filter(':visible').contains('등록된 URI').should('be.visible');
    // 3.0.3.0_R34785 표 처리 컬럼 없어짐
    // cy.get('th').filter(':visible').contains('처리').should('be.visible');
    cy.get('th').filter(':visible').contains('수집 제외').should('be.visible');
    cy.log('✅ 검출 - 검출메뉴관리 - [URI 관리] 출력 확인 완료 ');


    // 검출탭 > 검출 메뉴 관리 > URI 관리 룰 설정 화면 ------------------------------------------
    // 2.9.1.262_r35274 메뉴 규칙 설정 탭 문구변경 메뉴 규칙설정 -> URI 관리 룰
    cy.contains('.v-btn__content', 'URI 관리 룰').should('be.visible').click({ force: true });
    cy.wait(3000);
    cy.log('--- 화면 검증 시작 ---');

    // 좌측 - 업무시스템 목록 (동적 데이터 대응 + 신규 설치 시 빈 목록 방어)
    cy.contains('.v-card__title', '업무시스템 목록 (Master)').should('be.visible');

    cy.get('body').then(($body) => {
      const itemCount = $body.find('.v-list__tile__title:visible').length;

      if (itemCount === 0) {
        cy.log('ℹ️ 업무시스템 목록이 비어있음 (신규 설치 상태로 판단)');
      } else {
        cy.get('.v-list__tile__title').filter(':visible').should('have.length.greaterThan', 0).each(($title) => {
          cy.wrap($title).invoke('text').then((text) => {
            expect(text.trim().length).to.be.greaterThan(0);
          });
        });

        cy.get('.v-chip__content').filter(':visible').each(($chip) => {
          cy.wrap($chip).invoke('text').then((text) => {
            expect(text.trim().length).to.be.greaterThan(0);
          });
        });
      }
    });

    // 우측 - "0 정책 설정" 상단 헤더 영역
    cy.contains('h2', '정책 설정').should('be.visible');
    cy.contains('신규 설정 작성 중').should('be.visible');

    // 업무시스템 명 / 시스템 ID (Scope) 라벨 확인
    cy.contains('.caption', '업무시스템 명').should('be.visible');
    cy.contains('.caption', '시스템 ID (Scope)').should('be.visible');

    // URI 메뉴키 포함 여부 (is_global) 섹션
    cy.contains('h3', 'URI 메뉴키 포함 여부 (is_global)').should('be.visible');
    cy.contains('고객사가 제공한 키만으로 전역 유니크함 보장이 없으면 반드시 켜야 합니다.').should('be.visible');
    cy.contains('포함 (켬)').should('be.visible');
    cy.contains('포함 안 함 (끔)').should('be.visible');

    // 메뉴 키 조합 규칙 (Expressions) 섹션
    cy.contains('h3', '1. 메뉴 키 조합 규칙 (Expressions)').should('be.visible');
    cy.contains('.v-btn__content', '규칙 추가').should('be.visible');

    // 기본 규칙 1행 확인 (순번 칩, 드롭다운, 입력창, 삭제버튼)
    cy.get('.v-chip').filter(':visible').contains('1').should('be.visible');
    cy.get('select.custom-input').filter(':visible').first().within(() => {
      cy.get('option[value="RequestHeader"]').should('exist');
      cy.get('option[value="RequestBody"]').should('exist');
      cy.get('option[value="RequestParam"]').should('exist');
      cy.get('option[value="ResponseHeader"]').should('exist');
      cy.get('option[value="ResponseBody"]').should('exist');
    });

    // "키 이름 입력 (예: globalMenuId)" - 규칙이 여러 개 추가된 만큼 존재할 수 있음
    cy.get('input[placeholder="키 이름 입력 (예: globalMenuId)"]').filter(':visible').should('have.length.greaterThan', 0)
      .each(($input) => {
        cy.wrap($input).should('be.visible');
      });

    // 추가 속성 추출 정책 섹션
    cy.contains('h3', '2. 추가 속성 추출 정책 (선택사항)').should('be.visible');

    // 메뉴명 추출
    cy.contains('메뉴명 추출:').should('be.visible');
    cy.get('input[placeholder="키 이름 입력 (예: menuName) - 미입력 가능"]').filter(':visible').should('be.visible');

    // 행위구분 추출
    cy.contains('행위구분 추출:').should('be.visible');
    cy.get('input[placeholder="키 이름 입력 (예: action) - 미입력 가능"]').filter(':visible').should('be.visible');

    // 행위구분 맵핑 (Map) 섹션
    cy.contains('행위구분 맵핑 (Map):').should('be.visible');
    cy.contains('엑셀 양식에 기재되는 텍스트를 시스템 전용 숫자 코드로 변환하기 위한 맵핑입니다.').should('be.visible');
    cy.contains('.v-btn__content', '매핑 추가').should('be.visible');
    cy.contains('설정된 매핑이 없습니다.').should('be.visible');

    // 하단 저장 버튼
    cy.contains('.v-btn__content', '신규 정책 저장').should('be.visible');

    cy.log('✅ 검출 - 검출메뉴 관리 - [URI 관리 룰] 화면 확인 완료!');


    // 검출탭 > 검출 메뉴 관리 > URI 관리 일괄 등록 화면 ----------------------------------------
    // 2.9.1.262_r35274 메뉴 일괄등록 -> URI 관리 일괄 등록
    // [수정] 탭이 바로 안 뜨는 문제 - 일괄 등록 화면 고유 요소(표준 템플릿 다운로드)가 뜰 때까지 재시도
    const openBulkRegisterTab = (attempt = 1) => {
      cy.contains('.v-btn__content', 'URI 관리 일괄 등록').should('be.visible').click({ force: true });
      cy.wait(2000);

      cy.get('body').then(($body) => {
        const opened = $body.find('.v-btn__content:contains("표준 템플릿 다운로드"):visible').length > 0;
        if (opened) return;
        if (attempt >= 3) throw new Error('URI 관리 일괄 등록 화면 진입 실패');

        cy.log(`🔁 일괄 등록 화면 미표시 - 다른 탭 경유 후 재시도 (${attempt})`);
        cy.contains('.v-btn__content', 'URI 관리 룰').click({ force: true });
        cy.wait(1500);
        openBulkRegisterTab(attempt + 1);
      });
    };
    openBulkRegisterTab();

    cy.log('--- 화면 검증 시작 ---');

    // 좌측 - 업무시스템 목록 (동적 데이터 대응 + 신규 설치 시 빈 목록 방어)
    cy.contains('.v-card__title', '업무시스템 목록 (Master)', { timeout: 15000 }).should('be.visible');

    cy.get('body').then(($body) => {
      const itemCount = $body.find('.v-list__tile__title:visible').length;

      if (itemCount === 0) {
        cy.log('ℹ️ 업무시스템 목록이 비어있음 (신규 설치 상태로 판단)');
      } else {
        cy.get('.v-list__tile__title').filter(':visible').should('have.length.greaterThan', 0).each(($title) => {
          cy.wrap($title).invoke('text').then((text) => {
            expect(text.trim().length).to.be.greaterThan(0);
          });
        });

        cy.get('.v-chip__content').filter(':visible').each(($chip) => {
          cy.wrap($chip).invoke('text').then((text) => {
            expect(text.trim().length).to.be.greaterThan(0);
          });
        });
      }
    });

    // 우측 - 상단 헤더 영역
    // [변경] "메뉴 하이브리드 일괄등록" → "메뉴 복합 일괄 등록"
    // 앞부분("0 {0}")은 선택된 업무시스템 정보가 들어가는 자리로 보여 끝부분만 검증
    cy.get('h2.title').filter(':visible')
      .invoke('text')
      .should('match', /메뉴 복합 일괄 등록\s*$/);
    cy.get('h2.title').filter(':visible').find('.fa-file-upload').should('exist');

    // [확인 필요] 제목에 "{0}" 치환 안 된 문자열이 노출됨 - 버그로 판단되면 아래 주석 해제
    // cy.get('h2.title').filter(':visible').invoke('text').should('not.include', '{0}');

    // 표준 템플릿 다운로드 / 엑셀 업로드 버튼
    cy.contains('.v-btn__content', '표준 템플릿 다운로드').should('be.visible')
      .find('.fa-file-download').should('exist');
    cy.contains('.v-btn__content', '엑셀 업로드').should('be.visible')
      .find('.fa-file-upload').should('exist');
    // 숨겨진 파일 input - 엑셀 확장자만 허용
    cy.get('input[type="file"][accept=".xlsx, .xls"]').should('exist');

    // 경고 알림 (Alert) 영역 - 변경 없음
    cy.get('.v-alert--outline.warning--text').filter(':visible').should('be.visible').within(() => {
      cy.get('.v-alert__icon').should('contain.text', 'priority_high');
      cy.contains('경고:').should('be.visible');
      cy.contains('선택하신 업무시스템의 정책이 설정되어 있지 않습니다.').should('be.visible');
      cy.contains('[규칙설정] 메뉴에서 먼저 해당 시스템의 정책을 설정해 주세요.').should('be.visible');
    });

    // 안내 문구 (caption)
    // [변경] "업로드(또는 붙여넣기) 시" → "업로드 시"
    cy.contains('.caption', '업로드 시 엑셀 헤더와 선택한 시스템 규칙을 자동으로 매핑합니다. 불일치하는 경우 아래에서 수동으로 매핑할 수 있습니다.')
      .should('be.visible')
      .find('.material-icons').should('contain.text', 'info');

    // 이미 등록되어 있는 메뉴 목록
    // [신규] 제목 뒤에 건수 표시 "(N건)"
    cy.contains('h3', '이미 등록되어 있는 메뉴 목록').should('be.visible')
      .invoke('text').should('match', /이미 등록되어 있는 메뉴 목록 \(\d+건\)/);
    cy.contains('h3', '이미 등록되어 있는 메뉴 목록')
      .find('.material-icons').should('contain.text', 'check_circle');

    // 초기 상태 - 데이터 없음 안내 확인
    cy.contains('td', '등록된 메뉴 데이터가 없습니다.').should('be.visible');

    // 페이지네이션 영역 확인
    cy.contains('Rows per page:').should('be.visible');
    cy.get('.v-select__selection--comma').filter(':visible').contains('10').should('be.visible');
    cy.get('button[aria-label="Previous page"]').should('exist').and('be.disabled');
    cy.get('button[aria-label="Next page"]').should('exist').and('be.disabled');

    // 등록 대기중인 데이터
    // [신규] 제목 뒤에 건수 표시 "(N)"
    cy.contains('h3', '등록 대기중인 데이터').should('be.visible')
      .invoke('text').should('match', /등록 대기중인 데이터 \(\d+\)/);
    cy.contains('h3', '등록 대기중인 데이터').find('.fa-clock').should('exist');

    // 일괄 저장 버튼 - 초기 비활성화 상태 확인
    cy.contains('.v-btn__content', '일괄 저장').closest('button')
      .should('be.disabled')
      .find('.material-icons').should('contain.text', 'save');

    // 초기 상태 - 데이터 없음 안내 확인
    // [변경] "엑셀 파일을 업로드하거나 내용을 붙여넣어 주세요." → "엑셀 파일을 업로드 해주세요."
    cy.contains('업로드된 데이터가 없습니다. 엑셀 파일을 업로드 해주세요.').should('be.visible');

    cy.log('✅ 검출 - 검출 메뉴 관리 - [URI 관리 일괄 등록] 화면 확인 완료!');


    //==========================================
    // 검출탭 > 개인정보 유형 정의 서브메뉴 선택
    //=========================================
    cy.log('🚀 검출 - 개인정보 유형 정의선택 ');
    cy.contains('button', '검출').should('be.visible').click({ force: true });
    cy.wait(2000);

    // 검출탭 서브메뉴 - 개인정보 유형 정의 탭 (디폴트)
    cy.get('.v-list__tile__title').filter(':contains("개인정보 유형 정의")').filter(':visible').click({ force: true });
    cy.wait(3000);

    cy.log('---  개인정보 식별 유형 정의 화면 검증 시작 ---');
    cy.contains('.c-headline', '검색 조건').should('exist');
    cy.get('input[aria-label="개인정보 유형 명"]').should('be.visible');
    cy.contains('label.v-label', '정보주체만 조회').should('be.visible');
    cy.contains('label.v-label', '삭제된 유형 포함').should('be.visible');
    cy.get('.v-btn__content').filter(':visible').contains('검색').should('be.visible');

    // 표 데이터 테이블 헤더(컬럼명) 검증
    cy.log('✔️ 데이터 테이블 컬럼명 검증');
    const expectedHeaders = ['유형 명', '정보주체 설정', '주체 우선순위', '활성화', '등록일시', '수정일시'];
    expectedHeaders.forEach((headerName) => {
      cy.get('th').contains(headerName).should('be.visible');
    });

    // 우측 상단 신규 추가(+) 버튼 검증
    cy.log('✔️ 신규 추가 버튼 검증');
    cy.contains('i.material-icons', 'add').should('be.visible');
    cy.log('✅ 검출 - 개인정보 유형 정의 -  개인정보 식별 유형 정의 화면 UI 검증완료');


    // 검출탭 > 개인정보 유형 정의 > 식별 정규식 정의 탭 선택 ---------------------------------------
    cy.contains('.v-btn__content', '식별 정규식 정의').should('be.visible').click({ force: true });
    cy.wait(3000);
    cy.log('--- 식별 정규식 정의 화면 검증 시작 ---');
    cy.contains('span.title.font-weight-bold', '식별 정규식 정의').should('be.visible');

    // 본문(content) 설명란 검증 - 줄바꿈(<br>) 단위로 쪼개서 검증
    cy.get('span.content').should('be.visible')
      .and('contain', '한 가지 정보만으로 개인정보를 알 수 있는 항목')
      .and('contain', '식별자 판단 기준을 설정하면')
      .and('contain', '식별 정규식 수정 후 원활한 탐색을 위해 로그캐치 웹 매니저를 재기동해주시기 바랍니다.');

    cy.get('.v-icon.fa-plus').filter(':visible').should('be.visible');
    cy.get('.material-icons').filter(':visible').contains('autorenew').should('be.visible');
    cy.get('.v-icon.fa-search').filter(':visible').should('be.visible');

    cy.contains('label.text-label', '식별자 패턴 그룹').should('exist');
    cy.contains('label.text-label', 'Pattern Korea').should('exist');
    cy.contains('label.text-label', 'Pattern Korea2').should('exist');

    cy.contains('label.text-label', 'Pattern Korea').click({ force: true });
    cy.wait(2000);

    // Pattern Korea 표 컬럼 확인
    cy.get('th').contains('식별 정규식 패턴 설명').should('be.visible');
    cy.get('th').contains('확정').should('be.visible');
    cy.log('✅ 검출 - 개인정보 유형 정의 - 식별 정규식 정의 화면 UI 검증완료');


    // 검출탭 > 개인정보 유형 정의 > 식별 키워드 정의 탭 선택 ---------------------------------------
    cy.contains('.v-btn__content', '식별 키워드 정의').should('be.visible').click({ force: true });
    cy.wait(3000);
    cy.log('--- 식별 키워드 정의 화면 검증 시작 ---');
    cy.contains('span.title.font-weight-bold', '식별 키워드 정의').should('be.visible');

    cy.get('span.content')
      .should('be.visible')
      .and('contain', '식별된 키워드를 바탕으로 개인정보를 검출합니다.')
      .and('contain', '식별자 판단 기준을 설정하면, 보다 정확하게 개인정보 접근 여부를 판별할 수 있습니다.')
      .and('contain', '식별 키워드 수정 후 원활한 탐색을 위해 로그캐치 웹 매니저를 재기동해주시기 바랍니다.');

    // [신규] 좌측 트리 영역 - 추가(+) / 새로고침 아이콘
    cy.get('.v-icon.fa-plus').filter(':visible').should('be.visible');
    cy.get('.material-icons').filter(':visible').contains('autorenew').should('be.visible');

    // (개인정보 유형)
    cy.contains('span.sub-title-title', '식별 키워드 설정').should('be.visible');
    cy.get('input[aria-label="개인정보 유형"]').should('be.visible');

    // [신규] 유형 콤보박스 (기본값: 일치) - 개인정보 유형 우측
    cy.get('input[aria-label="유형"]').filter(':visible').should('be.visible');
    cy.get('input[aria-label="유형"]').filter(':visible')
      .closest('.v-input')
      .find('.v-select__selections')
      .should('contain.text', '일치');

    // 라디오 버튼 그룹
    // [변경] "적용 대상" → "대상 (Target)"
    cy.contains('.flex', '대상 (Target)').should('be.visible');
    // 기본값: "전역" 선택 / "업무시스템 지정" 미선택
    cy.get('input[role="radio"][aria-label="전역"]').should('exist')
      .and('have.attr', 'aria-checked', 'true')
      .and('have.value', '0');
    cy.get('input[role="radio"][aria-label="업무시스템 지정"]').should('exist')
      .and('have.attr', 'aria-checked', 'false')
      .and('have.value', '1');
    cy.contains('label.v-label', '전역').should('be.visible');
    cy.contains('label.v-label', '업무시스템 지정').should('be.visible');

    // 키워드 입력 영역 ("키워드 값 :")
    // [수정] 숨겨진 하단 검색 영역에도 같은 placeholder 입력창이 있어서 "키워드 값 :" 행 안으로 범위를 좁혀 확인
    cy.contains('.flex', '키워드 값 :').should('be.visible')
      .closest('.layout')
      .find('input[placeholder="항목을 입력하고 Enter 를 누르세요."]')
      .should('have.length', 1)
      .and('be.visible');

    // 키워드명 자동 등록 - 기본값: 체크됨
    cy.get('input[role="checkbox"][aria-label="키워드명 자동 등록"]').should('have.attr', 'aria-checked', 'true');
    cy.contains('label.v-label', '키워드명 자동 등록').should('be.visible');

    // 설명 입력창
    cy.get('input[aria-label="설명"]').filter(':visible').should('be.visible');

    // 확정 키워드 - 기본값: 체크 안 됨
    cy.get('input[role="checkbox"][aria-label="확정 키워드"]').should('have.attr', 'aria-checked', 'false');
    cy.contains('label.v-label', '확정 키워드').should('be.visible');

    // 저장 버튼 존재확인
    cy.get('.v-btn__content').filter(':visible').contains('저장').should('be.visible');

    // [변경] 하단 "검색 조건" 영역(업무 시스템 / 일치 / Content Type / 키워드 입력 / 검색 버튼)과
    //        "키워드 / 샘플" 테이블은 화면에서 숨김 처리됨
    //        → DOM에는 남아 있지만 부모(.v-card__actions)가 display: none
    //        → 좌측 트리 영역으로 대체된 것으로 보임
    cy.log('✔️ 하단 [검색 조건] 영역 - 숨김 상태 확인');
    cy.contains('.c-headline', '검색 조건')
      .should('exist')
      .and('not.be.visible')
      .closest('.v-card__actions')
      .should('have.css', 'display', 'none');

    cy.log('✅ 검출 - 개인정보 유형 정의 - 식별 키워드 정의 화면 UI 검증완료');


    //===========================================
    // 검출탭 > 행위 구분 정책관리 선택
    //===========================================
    cy.log('🚀 검출 - 행위 구분 정책 관리선택 ');
    cy.contains('button', '검출').should('be.visible').click({ force: true });
    cy.wait(2000);
    // 2.9.1.262_r35274 "행위 구분 정책 관리" -> "행위유형 관리" 메뉴 문구 수정
    cy.get('.v-list__tile__title').filter(':contains("행위유형 관리")').filter(':visible').click({ force: true });
    cy.wait(3000);
    cy.log('---  행위구분 정책 관리 화면 검증 시작 ---');
    cy.wait(1000);

    // 검색 조건 영역 검증
    cy.log('✔️ 검색 조건 영역 검증');
    cy.contains('.c-headline', '검색 조건').should('exist');
    cy.get('input[aria-label="업무시스템"]').should('be.visible');
    cy.get('input[aria-label="행위 유형"]').should('be.visible');
    cy.get('input[aria-label="URI 주소"]').should('be.visible');

    // 표 컬럼 확인
    cy.get('th').filter(':visible').contains('정책 ID').should('be.visible');
    // 2.9.1.262_r35274 띄워쓰기
    cy.get('th').filter(':visible').contains('업무 시스템').should('be.visible');
    cy.get('th').filter(':visible').contains('URI 주소 패턴').should('be.visible');
    cy.get('th').filter(':visible').contains('행위 유형').should('be.visible');

    cy.get('.v-btn__content').filter(':visible').contains('추가').should('be.visible');
    cy.get('.v-btn__content').filter(':visible').contains('검색').should('be.visible');

    cy.log('✅ 검출 - 행위유형 관리 - 정책 관리 UI 검증완료');


    // ==========================================
    // [FINAL] 테스트 종료 및 메뉴 닫기
    // ==========================================
    cy.log('🎉 검출 UI 테스트 시나리오 성공적으로 완료!');
    cy.get('body').type('{esc}');
    cy.get('body').click('center', { force: true });

  });
});

//코드마지막